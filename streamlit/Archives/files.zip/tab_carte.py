"""
Tab Carte — carte interactive Pydeck régions / départements.
Toggle région ↔ département, couleur = volume d'offres, clic = panneau détail.
"""
import json
import math
import os
import streamlit as st
import pandas as pd
import pydeck as pdk
import plotly.graph_objects as go

from utils.queries import (
    load_carte_regions,
    load_carte_departements,
    load_top_contrats_zone,
)
from utils.helpers import fmt_number, fmt_euro, base_layout
from config import GOLD, TEAL, CORAL, PURPLE, DARK_BG, GRID_COL, TEXT_COL

# ── Chemins GeoJSON (relatifs au répertoire de lancement de streamlit) ─────────
_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEOJSON_REGIONS = os.path.join(_DIR, "regions.geojson")
GEOJSON_DEPS    = os.path.join(_DIR, "departements.geojson")


# ── Helpers ────────────────────────────────────────────────────────────────────

def _centroid(coordinates):
    """Centroïde approximatif d'un polygone (ou multipolygone)."""
    all_pts = []
    def _flatten(c):
        if isinstance(c[0], (int, float)):
            all_pts.append(c)
        else:
            for sub in c:
                _flatten(sub)
    _flatten(coordinates)
    if not all_pts:
        return 2.0, 46.5
    return (
        sum(p[0] for p in all_pts) / len(all_pts),
        sum(p[1] for p in all_pts) / len(all_pts),
    )


def _color_scale(value, vmin, vmax, alpha=200):
    """
    Gradient : bleu foncé (peu d'offres) → or (beaucoup).
    Retourne [R, G, B, A].
    """
    if vmax == vmin:
        t = 0.5
    else:
        t = max(0.0, min(1.0, (value - vmin) / (vmax - vmin)))

    # Palette : #1a2a3a → #2a6a5a → #d4a84b
    if t < 0.5:
        s = t * 2
        r = int(26  + s * (42  - 26))
        g = int(42  + s * (106 - 42))
        b = int(58  + s * (90  - 58))
    else:
        s = (t - 0.5) * 2
        r = int(42  + s * (212 - 42))
        g = int(106 + s * (168 - 106))
        b = int(90  + s * (75  - 90))
    return [r, g, b, alpha]


def _build_geojson_layer(geojson_path: str, df: pd.DataFrame,
                          name_col: str, opacity: float) -> tuple[list, list]:
    """
    Fusionne le GeoJSON avec les données BDD.
    Retourne (features_enrichis, points_labels).
    """
    with open(geojson_path) as f:
        geo = json.load(f)

    # Index BDD par nom normalisé
    df_idx = df.set_index(df[name_col].str.strip().str.lower())
    vmin = int(df["nb_offres"].min())
    vmax = int(df["nb_offres"].max())

    features = []
    labels   = []

    for feat in geo["features"]:
        nom_geo  = feat["properties"].get("nom", "")
        nom_key  = nom_geo.strip().lower()
        code_geo = feat["properties"].get("code", "")

        if nom_key in df_idx.index:
            row = df_idx.loc[nom_key]
            # Gérer les doublons (prendre la première ligne)
            if isinstance(row, pd.DataFrame):
                row = row.iloc[0]
            nb       = int(row["nb_offres"])
            sal_moy  = row.get("salaire_moyen")
            sal_med  = row.get("salaire_mediane")
            nb_ent   = int(row.get("nb_entreprises", 0))
            offres30 = int(row.get("offres_30j", 0))
        else:
            nb = 0; sal_moy = None; sal_med = None; nb_ent = 0; offres30 = 0

        color = _color_scale(nb, vmin, vmax, alpha=210)

        new_feat = {
            "type": "Feature",
            "geometry": feat["geometry"],
            "properties": {
                "nom":            nom_geo,
                "code":           code_geo,
                "nb_offres":      nb,
                "nb_entreprises": nb_ent,
                "salaire_moyen":  float(sal_moy)  if sal_moy  is not None and not (isinstance(sal_moy,  float) and math.isnan(sal_moy))  else None,
                "salaire_mediane":float(sal_med)  if sal_med  is not None and not (isinstance(sal_med,  float) and math.isnan(sal_med))  else None,
                "offres_30j":     offres30,
                "fill_color":     color,
            },
        }
        features.append(new_feat)

        # Point centroïde pour le label
        lon, lat = _centroid(feat["geometry"]["coordinates"])
        labels.append({
            "lon":       lon,
            "lat":       lat,
            "nom":       nom_geo,
            "nb_offres": nb,
            "label":     f"{fmt_number(nb)}",
        })

    return features, labels


# ── Rendu principal ────────────────────────────────────────────────────────────

def render(_filters_key: str = ""):
    # ── Chargement données ─────────────────────────────────────────────────
    with st.spinner("Chargement des données carte…"):
        df_reg = load_carte_regions()
        df_dep = load_carte_departements()

    # ── Toggle niveau ──────────────────────────────────────────────────────
    st.markdown(
        """
        <style>
        div[data-testid="stHorizontalBlock"] > div:first-child { max-width: 320px; }
        </style>
        """,
        unsafe_allow_html=True,
    )

    col_toggle, col_info = st.columns([1, 3])
    with col_toggle:
        niveau = st.radio(
            "Niveau",
            options=["🗺️  Régions", "📍  Départements"],
            index=0,
            horizontal=False,
            label_visibility="collapsed",
        )

    is_region = "Région" in niveau

    df_active    = df_reg  if is_region else df_dep
    geojson_path = GEOJSON_REGIONS if is_region else GEOJSON_DEPS
    name_col     = "nom"

    with col_info:
        total = int(df_active["nb_offres"].sum())
        top   = df_active.iloc[0]
        st.markdown(
            f'<div style="padding:0.8rem 0 0;color:{TEXT_COL};font-size:0.85rem">'
            f'<span style="color:{GOLD};font-size:1.1rem;font-weight:600">{fmt_number(total)}</span> offres au total &nbsp;·&nbsp; '
            f'Zone la plus active : <span style="color:{TEAL}">{top["nom"]}</span> '
            f'({fmt_number(int(top["nb_offres"]))} offres)'
            f'</div>',
            unsafe_allow_html=True,
        )

    # ── Construction des layers ────────────────────────────────────────────
    features, labels = _build_geojson_layer(geojson_path, df_active, name_col, opacity=0.75)

    geojson_layer = pdk.Layer(
        "GeoJsonLayer",
        data={"type": "FeatureCollection", "features": features},
        pickable=True,
        stroked=True,
        filled=True,
        extruded=False,
        get_fill_color="properties.fill_color",
        get_line_color=[48, 52, 64, 255],
        line_width_min_pixels=1,
        auto_highlight=True,
        highlight_color=[212, 168, 75, 80],
    )

    text_layer = pdk.Layer(
        "TextLayer",
        data=labels,
        get_position=["lon", "lat"],
        get_text="label",
        get_size=13,
        get_color=[240, 237, 230, 220],
        get_anchor="'middle'",
        get_alignment_baseline="'center'",
        font_family="DM Sans",
        font_weight=600,
        pickable=False,
    )

    view_state = pdk.ViewState(
        longitude=2.5,
        latitude=46.5,
        zoom=4.8 if is_region else 5.0,
        pitch=0,
        bearing=0,
    )

    tooltip = {
        "html": """
            <div style="
                background:#1e2028;
                border:1px solid #3a3a44;
                border-radius:8px;
                padding:0.8rem 1rem;
                font-family:DM Sans,sans-serif;
                font-size:0.82rem;
                color:#e8e6e0;
                min-width:180px;
            ">
                <div style="font-size:1rem;font-weight:600;color:#d4a84b;margin-bottom:0.4rem">
                    {nom}
                </div>
                <div>📋 <b>{nb_offres}</b> offres</div>
                <div>🏢 <b>{nb_entreprises}</b> entreprises</div>
                <div>💶 Sal. moy. <b>{salaire_moyen} €</b></div>
                <div style="color:#6b6a66;margin-top:0.3rem;font-size:0.75rem">
                    Cliquer pour le détail
                </div>
            </div>
        """,
        "style": {"pointer-events": "none"},
    }

    deck = pdk.Deck(
        layers=[geojson_layer, text_layer],
        initial_view_state=view_state,
        tooltip=tooltip,
        map_style="mapbox://styles/mapbox/dark-v10",
        parameters={"depthTest": False},
    )

    # ── Affichage carte + panneau détail côte à côte ───────────────────────
    col_map, col_detail = st.columns([3, 1])

    with col_map:
        clicked = st.pydeck_chart(deck, use_container_width=True, height=580)

    with col_detail:
        _render_detail_panel(df_active, is_region, df_reg, df_dep)

    # ── Légende couleur ────────────────────────────────────────────────────
    _render_legend(df_active)


def _render_detail_panel(df_active: pd.DataFrame, is_region: bool,
                          df_reg: pd.DataFrame, df_dep: pd.DataFrame):
    """Panneau latéral : sélecteur + stats détaillées."""
    st.markdown(
        '<div style="font-size:0.72rem;font-weight:600;letter-spacing:0.1em;'
        'text-transform:uppercase;color:#5a5a64;margin-bottom:0.6rem">'
        '📊 Détail zone</div>',
        unsafe_allow_html=True,
    )

    # Sélecteur zone
    zones = df_active["nom"].sort_values().tolist()
    default_idx = 0
    # Mémoriser la sélection
    sel_key = "carte_sel_region" if is_region else "carte_sel_dep"
    prev = st.session_state.get(sel_key, zones[0] if zones else "")
    if prev in zones:
        default_idx = zones.index(prev)

    zone_sel = st.selectbox(
        "Choisir une zone",
        zones,
        index=default_idx,
        key=sel_key,
        label_visibility="collapsed",
    )

    if not zone_sel:
        return

    row = df_active[df_active["nom"] == zone_sel]
    if row.empty:
        st.caption("Pas de données.")
        return
    row = row.iloc[0]

    nb       = int(row["nb_offres"])
    nb_ent   = int(row.get("nb_entreprises", 0))
    sal_moy  = row.get("salaire_moyen")
    sal_med  = row.get("salaire_mediane")
    off30    = int(row.get("offres_30j", 0))

    # Part nationale
    total_nat = int(df_active["nb_offres"].sum())
    pct = (nb / total_nat * 100) if total_nat else 0

    # Rang
    rang = int(df_active["nb_offres"].rank(ascending=False).loc[
        df_active["nom"] == zone_sel
    ].iloc[0])

    st.markdown(
        f"""
        <div style="background:#16181f;border:1px solid #24262e;border-radius:10px;
                    padding:1rem;margin-bottom:0.6rem">
            <div style="font-size:0.68rem;color:#5a5a64;text-transform:uppercase;
                        letter-spacing:0.08em;margin-bottom:0.2rem">Offres</div>
            <div style="font-size:1.8rem;font-family:'DM Serif Display',serif;
                        color:#f0ede6;line-height:1">{fmt_number(nb)}</div>
            <div style="font-size:0.75rem;color:#4a4a52;margin-top:0.2rem">
                {pct:.1f}% du total national · rang #{rang}
            </div>
        </div>
        <div style="background:#16181f;border:1px solid #24262e;border-radius:10px;
                    padding:1rem;margin-bottom:0.6rem">
            <div style="font-size:0.68rem;color:#5a5a64;text-transform:uppercase;
                        letter-spacing:0.08em;margin-bottom:0.2rem">Salaire moyen</div>
            <div style="font-size:1.5rem;font-family:'DM Serif Display',serif;
                        color:{TEAL};line-height:1">{fmt_euro(sal_moy)}</div>
            <div style="font-size:0.75rem;color:#4a4a52;margin-top:0.2rem">
                Médiane : {fmt_euro(sal_med)}
            </div>
        </div>
        <div style="display:flex;gap:0.4rem;margin-bottom:0.6rem">
            <div style="flex:1;background:#16181f;border:1px solid #24262e;
                        border-radius:10px;padding:0.7rem">
                <div style="font-size:0.65rem;color:#5a5a64;text-transform:uppercase;
                            letter-spacing:0.08em">Entreprises</div>
                <div style="font-size:1.2rem;font-family:'DM Serif Display',serif;
                            color:{CORAL}">{fmt_number(nb_ent)}</div>
            </div>
            <div style="flex:1;background:#16181f;border:1px solid #24262e;
                        border-radius:10px;padding:0.7rem">
                <div style="font-size:0.65rem;color:#5a5a64;text-transform:uppercase;
                            letter-spacing:0.08em">30 derniers j.</div>
                <div style="font-size:1.2rem;font-family:'DM Serif Display',serif;
                            color:{PURPLE}">{fmt_number(off30)}</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Top contrats (chargement live)
    zone_type = "region" if is_region else "departement"
    try:
        df_ct = load_top_contrats_zone(zone_type, zone_sel)
        if not df_ct.empty:
            st.markdown(
                '<div style="font-size:0.68rem;color:#5a5a64;text-transform:uppercase;'
                'letter-spacing:0.08em;margin:0.6rem 0 0.3rem">Top contrats</div>',
                unsafe_allow_html=True,
            )
            ct_max = int(df_ct["nb"].max())
            for _, ct_row in df_ct.iterrows():
                pct_bar = int(ct_row["nb"] / ct_max * 100)
                st.markdown(
                    f"""
                    <div style="margin-bottom:0.3rem">
                        <div style="display:flex;justify-content:space-between;
                                    font-size:0.75rem;color:#9a9890;margin-bottom:2px">
                            <span>{ct_row['contract_type']}</span>
                            <span style="color:{GOLD}">{fmt_number(int(ct_row['nb']))}</span>
                        </div>
                        <div style="background:#24262e;border-radius:3px;height:4px">
                            <div style="background:{GOLD};width:{pct_bar}%;
                                        height:4px;border-radius:3px"></div>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
    except Exception:
        pass

    # Si vue département → afficher la région parente
    if not is_region and "nom_region" in row.index:
        region_nom = row.get("nom_region", "")
        if region_nom and not (isinstance(region_nom, float) and math.isnan(region_nom)):
            st.markdown(
                f'<div style="margin-top:0.6rem;font-size:0.75rem;color:#4a4a52">'
                f'📍 Région : <span style="color:#9a9890">{region_nom}</span></div>',
                unsafe_allow_html=True,
            )


def _render_legend(df: pd.DataFrame):
    """Barre de légende couleur sous la carte."""
    vmin = int(df["nb_offres"].min())
    vmax = int(df["nb_offres"].max())
    vmid = (vmin + vmax) // 2

    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:0.8rem;margin-top:0.4rem;
                    font-size:0.75rem;color:#6b6a66">
            <span>{fmt_number(vmin)}</span>
            <div style="flex:1;height:8px;border-radius:4px;
                        background:linear-gradient(to right, #1a2a3a, #2a6a5a, #d4a84b)">
            </div>
            <span>{fmt_number(vmax)}</span>
            <span style="margin-left:0.5rem">offres</span>
        </div>
        """,
        unsafe_allow_html=True,
    )
